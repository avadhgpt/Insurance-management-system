// import { Button, NavLink } from 'react-bootstrap';
// import Card from 'react-bootstrap/Card';
// import ListGroup from 'react-bootstrap/ListGroup';
// import 'bootstrap/dist/css/bootstrap.css';
// import axios from 'axios';
// import { Navigate, useNavigate } from 'react-router-dom';
// const serverUrl = "http://localhost:8080/healthinsurance";

// function HelathCard(props) {
//     const navigate = useNavigate();
//     var healthForm = JSON.parse(window.localStorage.getItem("healthForm"));
//     var values = {
//         "startDate": new Date(),
//         "diseases": healthForm.diseases,
//         "age": healthForm.age,
//         "gender": healthForm.gender,
//         "vendorName": props.vendorName,
//         "vendorId": props.vendorId,
//         "premium": props.preminum,
//         "idvCover": props.idvCover,
//         "claimSetted": props.claimsSettled,
//         "addOns": props.addOnns,
//         "clientId": window.localStorage.getItem("clientId")
//     }
//     var handleClick = () => {
//         // console.log(values);
//         // console.log(carForm);
//         axios.post(serverUrl, values).then((response) => {
//             console.log("hurrayyyy!!!!")
//             if (response.data == true) {
//                 console.log("hurrayyyy!!!!");
//                 console.log(response.data);
//                 console.log(response);
//                 alert("Insurance bought successfully!");
//                 // const token = '12345';
//                 // storeTokenInLS(token);
//                 navigate('/home')
//                 // setSubmitted(true);
//                 // temp = true;
//             }
//             else {
//                 alert("Something went wrong!");
//             }
//         });
        
//     }
//     return (
//         <div>
//             <Card style={{ width: '18rem' }}>
//                 {/* <Card.Img variant="top" src="holder.js/100px180?text=Image cap" /> */}
//                 <Card.Body>
//                     <Card.Title>{props.vendorName}</Card.Title>
//                 </Card.Body>
//                 <ListGroup className="list-group-flush">
//                     <ListGroup.Item>Cover: ₹ {props.idvCover}</ListGroup.Item>
//                     <ListGroup.Item >Claims Settled: {props.claimsSettled}</ListGroup.Item>
//                     <ListGroup.Item >{props.addOnns}</ListGroup.Item>
//                 </ListGroup>
//                 <Card.Body>
//                     <Button onClick={handleClick} >Buy @ ₹ {props.preminum}</Button>
//                 </Card.Body>
//             </Card>
//         </div>
//     );
// }

// export default HelathCard;

import React, { useState } from 'react';
import { Button, Modal, Form } from 'react-bootstrap';
import Card from 'react-bootstrap/Card';
import ListGroup from 'react-bootstrap/ListGroup';
import 'bootstrap/dist/css/bootstrap.css';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const serverUrl = "http://localhost:8080/healthinsurance";

function HealthCard(props) {
    const navigate = useNavigate();
    const [show, setShow] = useState(false);
    const [paymentDetails, setPaymentDetails] = useState({ cardNumber: '', expiryDate: '', cvv: '' });

    const healthForm = JSON.parse(window.localStorage.getItem("healthForm"));
    const values = {
        startDate: new Date(),
        diseases: healthForm.diseases,
        age: healthForm.age,
        gender: healthForm.gender,
        vendorName: props.vendorName,
        vendorId: props.vendorId,
        premium: props.premium,
        idvCover: props.idvCover,
        claimsSettled: props.claimsSettled,
        addOns: props.addOns,
        clientId: window.localStorage.getItem("clientId"),
    };

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);

    const handlePaymentChange = (e) => {
        const { name, value } = e.target;
        setPaymentDetails({ ...paymentDetails, [name]: value });
    };

    const handleSubmit = () => {
        // You can add payment validation here if necessary
        axios.post(serverUrl, values).then((response) => {
            if (response.data === true) {
                alert("Insurance bought successfully!");
                navigate('/home');
            } else {
                alert("Something went wrong!");
            }
        });
        handleClose();
    };

    return (
        <div>
            <Card style={{ width: '18rem' }}>
                <Card.Body>
                    <Card.Title>{props.vendorName}</Card.Title>
                </Card.Body>
                <ListGroup className="list-group-flush">
                    <ListGroup.Item>Cover: ₹ {props.idvCover}</ListGroup.Item>
                    <ListGroup.Item>Claims Settled: {props.claimsSettled}</ListGroup.Item>
                    <ListGroup.Item>{props.addOnns}</ListGroup.Item>
                </ListGroup>
                <Card.Body>
                    <Button onClick={handleShow}>Buy @ ₹ {props.preminum}</Button>
                </Card.Body>
            </Card>

            <Modal show={show} onHide={handleClose}>
                <Modal.Header closeButton>
                    <Modal.Title>Payment Gateway</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Form>
                        <Form.Group controlId="formCardNumber">
                            <Form.Label>Card Number</Form.Label>
                            <Form.Control
                                type="text"
                                placeholder="Enter card number"
                                name="cardNumber"
                                value={paymentDetails.cardNumber}
                                onChange={handlePaymentChange}
                            />
                        </Form.Group>

                        <Form.Group controlId="formExpiryDate">
                            <Form.Label>Expiry Date</Form.Label>
                            <Form.Control
                                type="text"
                                placeholder="MM/YY"
                                name="expiryDate"
                                value={paymentDetails.expiryDate}
                                onChange={handlePaymentChange}
                            />
                        </Form.Group>

                        <Form.Group controlId="formCVV">
                            <Form.Label>CVV</Form.Label>
                            <Form.Control
                                type="text"
                                placeholder="Enter CVV"
                                name="cvv"
                                value={paymentDetails.cvv}
                                onChange={handlePaymentChange}
                            />
                        </Form.Group>
                    </Form>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={handleClose}>
                        Close
                    </Button>
                    <Button variant="primary" onClick={handleSubmit}>
                        Submit Payment
                    </Button>
                </Modal.Footer>
            </Modal>
        </div>
    );
}

export default HealthCard;
