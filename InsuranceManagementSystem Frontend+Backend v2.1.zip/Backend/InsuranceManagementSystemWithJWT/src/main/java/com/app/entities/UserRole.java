package com.app.entities;

public enum UserRole {
	CLIENT, VENDOR, ADMIN
}
