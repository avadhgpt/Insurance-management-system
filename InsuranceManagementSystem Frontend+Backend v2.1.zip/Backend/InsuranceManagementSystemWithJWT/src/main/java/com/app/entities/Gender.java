package com.app.entities;

public enum Gender {
	Male, Female
}
