//package com.app.services;
//
//import java.util.List;
//
//public interface PolicyService {
//
//	List<Policy> getAllPoliciesOfUser(int clientId);
//
//	List<Policy> getAllPolicy();
//
//}
